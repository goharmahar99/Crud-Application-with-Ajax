<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "blog_management_ajax";



?>