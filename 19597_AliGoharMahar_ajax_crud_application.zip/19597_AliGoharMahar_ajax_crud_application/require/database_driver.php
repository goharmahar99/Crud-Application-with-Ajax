<?php
class blog_management_ajax{
      public $hostname;
      public $username;
      public $password;
      public $database;
      public $connection;
      public $execute;
      
      
      
	public function __construct($hostname,$username,$password,$database){
          $this->hostname = $hostname;
          $this->username = $username;
          $this->password = $password;
          $this->database = $database;
          

     $this->connection = mysqli_connect($this->hostname,$this->username,$this->password,$this->database); 
        
     if(mysqli_connect_errno()){
        echo "Connection Failed....<br>";
        echo "Error No: ".mysqli_connect_errno()."<br>";
        echo "Error Msg: ".mysqli_connect_error();
 
         }
	}

	public function execute_query($query){
     $this->execute = mysqli_query($this->connection,$query); 
      return $this->execute;
      
	}
}


?>