<?php
session_start();
   if($_SESSION['user_info']['user_id']??""){
     header("location:dashboard.php");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login Page</title>
	<style>
		fieldset{
			 width: 500px;
			 height: auto;
			 background-color: lightgray;
			 border-radius: 10px;
		}
		legend{
			background-color: navy;
			border-radius: 10px;
			color: white;
			font-family: cursive;
		}
		h1{
			width: 500px;
			height: 60px;
			background-color: olive;
			color: white;
			font-family: cursive;
            padding: 5px;
			box-sizing: border-box;
			border-radius: 10px;
			box-shadow: 5px 10px 20px grey;
		}
		input{
		     font-size: 17px;
		     border-radius: 5px;
		}
		input[name="login"]:hover{
			background-color: green;
			color: white;
		}
	</style>
</head>
<body>
	    <center>
	    	    <h1>Login Here</h1>
	   		<p style="color:<?= $_GET['color']??'';?>"><b><?= $_GET['msg']??"";?></b></p>

	    	<fieldset>
	    		<legend>Login Here</legend>
	    		 <form action="process.php" method="POST">
	    			<table cellpadding="5" cellspacing="5">
	    				<tr>
	    				<th>Email : </th>
	    				<td> <input type="text" name="email"></td>
	    				</tr>
	    				<tr>
	    				<th>Password : </th>
	    				<td> <input type="password" name="password"></td>
	    				</tr>
	    				<tr align="center">
	    					<td colspan="2"> <input type="submit" name="login" value="Login"></td>
	    				</tr>
	    			</table>
                 </form>
	    	</fieldset>
	    	<p>If you have not account <a href="index.php">Click Here</a> for Register..</p>
	    </center>
</body>
</html>