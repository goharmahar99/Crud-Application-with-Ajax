/*
SQLyog Ultimate v12.5.0 (64 bit)
MySQL - 10.4.27-MariaDB : Database - blog_management_ajax
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`blog_management_ajax` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `blog_management_ajax`;

/*Table structure for table `post` */

DROP TABLE IF EXISTS `post`;

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `post_title` varchar(30) DEFAULT NULL,
  `post_description` longtext DEFAULT NULL,
  PRIMARY KEY (`post_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `post_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `post` */

insert  into `post`(`post_id`,`user_id`,`post_title`,`post_description`) values 
(1,1,'2','afasfd'),
(2,1,'post_3','This is post 3'),
(3,1,'post_3','This is post 3'),
(4,1,'post_title 4','This is post 4'),
(5,1,'post_title 4','This is post 4'),
(6,1,'post_title 5','This is post 5'),
(7,1,'post_title 6','This is post 6'),
(8,1,'post_title 6','This is post 6'),
(9,1,'post_title 7','This is post 7'),
(10,1,'post_title 7','This is post 7'),
(11,1,'post_title 7','This is post 7'),
(12,1,'post_title 8','This is post 8'),
(13,1,'post_title 9','This is post 9'),
(14,1,'post_title 10','This is post 10'),
(22,1,'post_title 11','This is post 11 '),
(23,1,'post_title 12','This is post 12'),
(25,1,'post_title 13','This is post 13'),
(27,1,'post_title 14','This is post 14');

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `email` varchar(25) DEFAULT NULL,
  `password` varchar(25) DEFAULT NULL,
  `cnic_number` varchar(25) DEFAULT NULL,
  `phone_number` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `gender` enum('Male','Female') DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `users` */

insert  into `users`(`user_id`,`first_name`,`last_name`,`email`,`password`,`cnic_number`,`phone_number`,`country`,`gender`) values 
(1,'Ali','Gohar','gohar@gmail.com','1234','12345-1234567-1','+92345-1234567','Turkey','Male'),
(2,'Ali','Gohar','gohar@gmail.com','1234','12345-1234567-1','+92345-1234567','Turkey','Male'),
(3,'Ali','Gohar','gohar@gmail.com','1234','12345-1234567-1','+92345-1234567','Turkey','Male');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
